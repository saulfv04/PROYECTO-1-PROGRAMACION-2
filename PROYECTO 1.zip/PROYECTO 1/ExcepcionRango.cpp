#include "ExcepcionRango.h"

ExcepcionRango::ExcepcionRango(int mx, int mn):max(mx),min(mn){}

ExcepcionRango::~ExcepcionRango(){}

string ExcepcionRango::toString()
{
	return toString();
}
