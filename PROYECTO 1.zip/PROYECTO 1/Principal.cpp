#include "Controlador.h"

int main() {

	Controlador C0;
	C0.control0();
	system("pause");
	return 0;
}