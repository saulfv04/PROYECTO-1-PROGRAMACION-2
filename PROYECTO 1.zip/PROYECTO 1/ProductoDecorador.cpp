#include "ProductoDecorador.h"
#include "Categoria.h"
ProductoDecorador::~ProductoDecorador(){
    cout << "Borrando Decoradores" << endl;

}

